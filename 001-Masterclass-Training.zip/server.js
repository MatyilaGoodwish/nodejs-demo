const http = require("http");

const express = require("express");

const hbs = require("hbs");

hbs.registerPartials(__dirname + "/views/partials");

const app = express();

app.set("view engine", "hbs");

app.get("/", (request, response)=>{
    //first argument template, second is data object
    response.render("default", {
        page:{
            title: "Home page",
            description: "this is the home page desc"
        }
    })
})

http.createServer(app).listen(3001); //port vary depending on your server
